#ifndef ANALYSIS_H
#define ANALYSIS_H
int advantage(int, int**);
void high_low(int *, int *, int *, int *, int **);
void rankings(int, int *, int *, int **);
void score_scale(int **, int *, int **);
#endif